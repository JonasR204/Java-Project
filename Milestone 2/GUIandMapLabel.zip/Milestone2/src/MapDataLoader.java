//DIESE KLASSE LIESST .net.xml daten
import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MapDataLoader {

    public static List<LaneShape> loadLanes(String netFilePath) {
        List<LaneShape> lanes = new ArrayList<>();

        try {
            File file = new File(netFilePath);
            if (!file.exists()) {
                System.out.println("Net-Datei nicht gefunden: " + netFilePath);
                return lanes;
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();

            NodeList laneNodes = doc.getElementsByTagName("lane");

            for (int i = 0; i < laneNodes.getLength(); i++) {
                Node laneNode = laneNodes.item(i);
                if (laneNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element laneElem = (Element) laneNode;
                    String shapeStr = laneElem.getAttribute("shape");
                    if (shapeStr == null || shapeStr.isEmpty()) continue;

                    LaneShape laneShape = new LaneShape();

                    // shape z.B.: "0.0,0.0 100.0,0.0 200.0,50.0"
                    String[] pointStrs = shapeStr.split(" ");
                    for (String p : pointStrs) {
                        String[] xy = p.split(",");
                        if (xy.length != 2) continue;
                        double x = Double.parseDouble(xy[0]);
                        double y = Double.parseDouble(xy[1]);
                        laneShape.addPoint(x, y);
                    }

                    lanes.add(laneShape);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lanes;
    }
}
