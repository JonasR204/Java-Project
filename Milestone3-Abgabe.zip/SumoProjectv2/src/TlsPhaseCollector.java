import java.util.*;

/**
 * Manages and tracks the phases of a traffic light, allowing for changes to the duration of each phase
 */
public class TlsPhaseCollector {

    private Integer lastAppliedPhase = null;
    private final SimulationController controller;
    private final String tlsId;

    private final List<PhaseEntry> phases = new ArrayList<>();

    /**
     * Initializes a TlsPhaseCollector for a given traffic light
     * @param controller Simulation controller reference to change the traffic light phases
     * @param tlsId Traffic light ID to manage
     */
    public TlsPhaseCollector(SimulationController controller, String tlsId) {
        this.controller = controller;
        this.tlsId = tlsId;
    }

    /**
     * First clears all existing phases and creates new PhaseEntry objects for the traffic light
     *
     * @param durations List of phase in seconds (double)
     * @param states List of states as a string ("GrGr")
     */
    public void initialize(List<Double> durations, List<String> states) {
        phases.clear();

        int count = Math.min(durations.size(), states.size());

        for (int i = 0; i < count; i++) {
            phases.add(
                    new PhaseEntry(i, states.get(i), durations.get(i))
            );
        }
    }

    public List<PhaseEntry> getPhases() {
        return phases;
    }

    /**
     * Updates state by iterating through simulation controller
     * @throws Exception If simulation is not running
     */
    public void observe() throws Exception {
        int current = controller.getTlsPhase(tlsId);

        for (PhaseEntry p : phases) {
            if (p.index == current) {
                p.state = controller.getRedYellowGreenState(tlsId);
                break;
            }
        }
    }

    /**
     * Applies user inputted duration changes to the traffic light in the SUMO simulation
     */
    public void applyDurationIfPhaseChanged() {
        try {
            int currentPhase = controller.getTlsPhase(tlsId);

            // Only apply once per phase
            if (lastAppliedPhase != null && lastAppliedPhase == currentPhase) {
                return;
            }

            PhaseEntry p = phases.get(currentPhase);

            int seconds;
            try {
                seconds = Integer.parseInt(p.durationField.getText().trim());
            } catch (NumberFormatException e) {
                return; // ignore invalid input
            }

            if (seconds <= 0) seconds = 1;

            // store edited value
            p.duration = seconds;

            controller.setTlsPhaseDuration(tlsId, seconds);

            lastAppliedPhase = currentPhase;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}