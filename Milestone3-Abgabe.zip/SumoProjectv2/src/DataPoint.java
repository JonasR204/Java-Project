import java.time.Instant;

public interface DataPoint {
    Instant timestamp();
}
