import javax.swing.*;

/**
 * Represents a single traffic light phase
 */
public class PhaseEntry {
    public final int index;
    public String state;
    public double duration;
    public final JTextField durationField;

    /**
     * Initializes the phase with index, state and duration
     * @param index Index of this phase in the traffic light logic
     * @param state State of the Traffic light (e.g. "GrGr")
     * @param duration Phase duration in seconds
     */
    public PhaseEntry(int index, String state, double duration) {
        this.index = index;
        this.state = state;
        this.duration = duration;
        this.durationField = new JTextField(String.valueOf((int)duration), 5);
    }
}