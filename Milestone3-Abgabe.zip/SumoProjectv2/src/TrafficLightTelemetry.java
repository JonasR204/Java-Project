import java.time.Instant;

/**
 * Represents a single telemetary data point for a traffic light, like current phase, state etc
 */
public class TrafficLightTelemetry implements DataPoint {

    private final Instant timestamp;
    private final String tlsId;
    private final int phase;
    private final String state;

    /**
     * Initializes a Telementary with timestamp, ID, phase and state
     * @param timestamp Current time stamp
     * @param tlsId Traffic light ID
     * @param phase Current active phase index
     * @param state State string ("yellow", "green" or "red")
     */
    public TrafficLightTelemetry(Instant timestamp, String tlsId, int phase, String state) {
        this.timestamp = timestamp;
        this.tlsId = tlsId;
        this.phase = phase;
        this.state = state;
    }

    @Override
    public Instant timestamp() {
        return timestamp;
    }

    public String getTlsId() { return tlsId; }
    public int getPhase() { return phase; }
    public String getState() { return state; }
}
