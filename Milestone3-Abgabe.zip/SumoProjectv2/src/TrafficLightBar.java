import java.awt.*;

/**
 * Represents a visual bar for a single traffic light on a lane
 */
public class TrafficLightBar{
    public final String tlsId;
    public final String laneId;
    public final int indexInState;

    public final double x1, y1;
    public final double x2, y2;

    private Color color = Color.GRAY;

    /**
     * Initializes the Traffic light bar
     *
     * @param tlsId Traffic light ID
     * @param laneId Lane ID
     * @param indexInState the index into the SUMO RYG state string
     * @param x1 x-coordinate of the start point
     * @param y1 y-coordinate of the start point
     * @param x2 x-coordinate of the end point
     * @param y2 y-coordinate of the end point
     */
    public TrafficLightBar(String tlsId, String laneId, int indexInState, double x1, double y1, double x2, double y2) {
        this.tlsId = tlsId;
        this.laneId = laneId;
        this.indexInState = indexInState;
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public Color getColor() {
        return color;
    }

    /**
     * Updates the Color of the traffic light bar based on SUMO
     * @param c the traffic light state character from SUMO
     */
    public void setStateChar(char c) {
        switch (c) {
            case 'r':
            case 'R':
                color = Color.RED;
                break;
            case 'y':
            case 'Y':
                color = Color.YELLOW;
                break;
            case 'g':
            case 'G':
                color = Color.GREEN;
                break;
            default:
                color = Color.DARK_GRAY;
        }
    }
}