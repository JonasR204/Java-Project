import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents the shape of a SUMO lane by storing its name and a List storing the lane's path
 */
public class LaneShape {

    private final String id;
    private final List<Point2D.Double> points = new ArrayList<>();

    /**
     * Constructor setting ID
     *
     * @param id unique ID name
     */
    public LaneShape(String id) {
        this.id = id;
    }


    public String getId() {
        return id;
    }

    /**
     * Add a new Point which represents a point along the lane
     *
     * @param x Coordinate x
     * @param y Coordinate y
     */
    public void addPoint(double x, double y) {
        points.add(new Point2D.Double(x, y));
    }

    public List<Point2D.Double> getPoints() {
        return points;
    }
}