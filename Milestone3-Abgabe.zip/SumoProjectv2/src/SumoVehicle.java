import java.awt.Color;
import java.awt.geom.Point2D;

/**
 * Represents a single vehicle in the SUMO simulation
 */
public class SumoVehicle {

    private String id;
    private double x;
    private double y;
    private Color color = Color.BLUE;
    private double angle;

    private final SimulationController controller;

    /**
     * Creates a vehicle wrapper with id and controller
     * @param id Unique vehicle ID
     * @param controller Simulation controller reference to access vehicle simulation data
     */
    public SumoVehicle(String id, SimulationController controller) {
        this.id = id;
        this.controller = controller;
    }

    public String getId() {
        return id;
    }

    /**
     * Updates the vehicles current position
     * @param p New vehicle position in world coordinates
     */
    public void updatePosition(Point2D.Double p) {
        if (p == null) return;
        x = p.x;
        y = p.y;
    }

    /**
     * Refreshes the vehicle's color, position and rotation based on the simulation
     * @throws Exception if vehicle doesn't exist or Traci communication failed
     */
    public void refresh() throws Exception {
        updatePosition(controller.getVehiclePosition(id));
        color = controller.getVehicleColor(id);
        this.angle = controller.getVehicleAngle(id);
    }

    public double getX() { return x; }
    public double getY() { return y; }

    public Color getRenderColor() {
        return color;
    }

    public double getSpeed() throws Exception {
        return controller.getVehicleSpeed(id);
    }

    public String getCurrentEdge() throws Exception {
        return controller.getVehicleEdge(id);
    }

    public Color getColor() {
        return color;
    }

    public double getAngle() {
        return angle;
    }

}