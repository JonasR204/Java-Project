import org.w3c.dom.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Loads lane geometry data from a .net.xml file
 */
public class MapDataLoader {

    /**
     * .net.xml file is read, extracts all lane elements, converting their shape attributes
     * into a list of 2D points stored in LaneShape objects
     *
     * @param netFilePath The SUMO .net.xml File to be read
     * @return List of all parsed lanes or empty list if the .net.xml file is missing or an error occured
     */
    public static List<LaneShape> loadLanes(String netFilePath) {
        List<LaneShape> lanes = new ArrayList<>();

        try {
            File file = new File(netFilePath);
            if (!file.exists()) {
                System.out.println("Net-Datei nicht gefunden: " + netFilePath);
                return lanes;
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(file);
            doc.getDocumentElement().normalize();

            NodeList laneNodes = doc.getElementsByTagName("lane");

            for (int i = 0; i < laneNodes.getLength(); i++) {
                Node laneNode = laneNodes.item(i);
                if (laneNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element laneElem = (Element) laneNode;
                    String shapeStr = laneElem.getAttribute("shape");
                    if (shapeStr == null || shapeStr.isEmpty()) continue;

                    String laneId = laneElem.getAttribute("id");
                    LaneShape laneShape = new LaneShape(laneId);


                    String[] pointStrs = shapeStr.split(" ");
                    for (String p : pointStrs) {
                        String[] xy = p.split(",");
                        if (xy.length != 2) continue;
                        double x = Double.parseDouble(xy[0]);
                        double y = Double.parseDouble(xy[1]);
                        laneShape.addPoint(x, y);
                    }

                    lanes.add(laneShape);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return lanes;
    }
}